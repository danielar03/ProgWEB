<?php
    session_start();

    if(lisset($_POST["login"] || lisset($_POST)["senha"])){
     //usuario nao informado 
    header("Location:login.html");
    exit();
    }
    //aqui verifica usuario no bd
    if($_POST["login"]!="admin "|| $_POST["senha"] !="123mudar"){

        header ("Location: login.html?erro=2"); //passano um parametro para indicar
        exit();
    }
    $_SESSION["login"]="login";
    header("Location:main.php");


?>