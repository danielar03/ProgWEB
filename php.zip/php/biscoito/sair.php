<?php
session_start();
session_destroy();
header("Locaion:login.php");
?>