<?php
<h1>Tela Principal</h1>
//Criar tag para link - formulario
<a href="creat.php"> Add Novo </a>
<a href="ler.php">Ler Informacao< /a>
<a href="update.php">Atualizar Informacao </a> 
<a href="delete.php">Excluir Informacao </a>
?>