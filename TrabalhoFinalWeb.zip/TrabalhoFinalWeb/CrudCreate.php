<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    //rel="stylesheet" =  define a interface usando o arquivo CSS
    <link rel="stylesheet" type="text/css" href="style.css">  
</head>
<body>
    
    <h1>Cadastrar um novo cliente </h1>
    <form action="create.php" method="post">
        <label for="name">Nome:</label>
        input type="text" id="name" name="name">
        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone">
        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email">
        <label for="data_nascimento">Data de Nascimento:</label>
        <input type="date" id="data_nascimento" name="data_nascimento">
        <button type="submit">Adicionar</button>
        </form>
    <?php
    //variavel global php retorna metodo em html
    if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
        include 'db.php'; // inclui o arquivo php no script - estabelecer conexao do banco de dados 
        //metodos 
        $name = $_POST['name'];
        $telefone = $_POST['telefone'];
        $email = $_POST['email'];
        $data_nascimento = $_POST['data_nascimento'];
        $sql = "INSERT INTO pessoas (nome, telefone, email, data_nascimento) 
        VALUES ('$name', '$telefone', '$email', '$data_nascimento')";
        //executar o sql 
        if ($conn->query($sql) === TRUE) {  
            echo "Registro criado com sucesso!";
        } 
        else {
            echo "Erro: " . $sql . "<br>" . $conn->error;
        }
        $conn->close(); //fecha conexao
    }
    //ver como faz para voltar
    ?>
    <a href="listagem.php">Voltar à Listagem</a>
    

</body>
</html>
