<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

  <h1>Listagem de cadastros</h1>
  <form action="listagem.php" method="get">
    <input type="text" name="search" placeholder="Pesquisar">
    <button type="submit">Pesquisar</button>
</form>

//criar tabela - cabecalho
<table>
    <thead>
        <tr>
            <th>Código</th>
            <th>Nome</th>
            <th>Telefone</th>
            <th>E-mail</th>
            <th>Data de Nascimento</th>
            <th>Ação</th>
        </tr>
</thead>



</body>
</html>