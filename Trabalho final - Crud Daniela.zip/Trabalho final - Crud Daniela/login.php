<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        //definir a aparência dos textos e campos de entrada
        *{margin: 0px;} 
        label{font: 20pt normal black; margin-top: 4%; font-family: georgia;}
        input{font: 20pt normal black; margin-top: 4%; font-family: georgia;}
        p{font: 20pt bold red; margin-top: 2%; font-family: georgia; color:red;}
        body{display: flex;align-items: center; justify-content: center; min-height: 100vh;flex-direction: column;}
        fieldset{display: flex;align-items: center; justify-content: center;flex-direction: column; background-color:white; border: 2px solid black;}
        form{display: flex;align-items: center; justify-content: center;flex-direction: column; }
    </style>
</head>
<body>
    <fieldset>  //agrupa os campos do formulário
        <form action="loginControle.php" method="post"> //tiliza o método post e será enviado para o arquivo loginControle.php
            <label for="usuario">Insira seu usuário: </label>
            <input type="text" name="usuario" id="usuario">
            <label for="senha">Insira sua senha: </label>
            <input type="password" name="senha" id="senha">
            <input type="submit" value="Login">
        </form>
    </fieldset>

    <?php
    //Se for verdadeiro o usuario já vai estar logado ou seja vai ser redirecionado para a página usuarios.php
    //faz com que o navegador do usuário seja redirecionado para a página 
    session_start();
    if(isset($_SESSION['logado'])){
        if($_SESSION['logado'] == true){
            header("location:usuarios.php");
        }
    }
    if(isset($_REQUEST['login'])){
        if($_REQUEST['login'] == 0){
            echo "<p> Usuario ou senha Inválidos</p>";
        }
    }
    ?>
</body>
</html>