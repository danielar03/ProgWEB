<?php
//autenticação de um usuário

    session_start(); //armazene e recupere dados entre diferentes páginas
    if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){ // Armazena e recupere dados entre outras páginas
        if($_REQUEST['usuario'] == "admin" && $_REQUEST['senha'] == "1597"){
            $_SESSION['logado'] = true;
            header("location:usuarios.php");
        }else{
            //redireciona o usuário de volta para a página de login
            header("location:login.php?login=0");
        }
    }else{
        //Dessa forma redireciona para a página de Login
        header("location:login.php?");
    }
?>