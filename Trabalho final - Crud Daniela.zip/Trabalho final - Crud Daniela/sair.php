<?php
    session_start(); //NOVA OU ANTIGA SESSAO
    session_destroy(); //DESTROI AS VARIAVEIS ARMAZENADAS
    header("location:login.php"); //ENVIA PARA A PÁGINA 
?>