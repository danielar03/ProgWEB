<?php 
//Estabelecendo uma coneção com o banco de dados
    function conecta(){
        $user="root";
        $senha="aluno";
        $database="crudphp";
        $host="localhost";
        

        //cria uma nova instancia (PDO), o qual utilizada para conectar com o banco de dados
        $db = new PDO("mysql:host=$host;dbname=$database",$user,$senha);
        //retornar a conexao
        if($db){
            return $db;
        }else{
            return false;
        }
    }

    function chekConexao($connId){
        if($connId){
            echo "conectado";
        }else{
            echo "não foi possivel conectar";
        }
    }

    //receber novos dados e usuarios
    function save($nome,$dataNasc,$telefone,$email){
        $db = conecta();

        $sql = "insert into usuario (nome,dataNasc,telefone,email) values (?,?,?,?)";

        $stmt = $db ->prepare($sql);
        $stmt->bindValue(1,$nome);
        $stmt->bindValue(2,$dataNasc);
        $stmt->bindValue(3,$telefone);
        $stmt->bindValue(4,$email);
        $stmt->execute();
    }

    function update($nome,$dataNasc,$telefone,$email,$id){
        $db = conecta();

        $sql = "update usuario set nome=?,dataNasc=?,telefone=?,email=? where idusuario = ?";

        $stmt = $db ->prepare($sql);
        $stmt->bindValue(1,$nome);
        $stmt->bindValue(2,$dataNasc);
        $stmt->bindValue(3,$telefone);
        $stmt->bindValue(4,$email);
        $stmt->bindValue(5,$id);
        $stmt->execute();
    }

    // deleta de acordo com o id fornecido 
    function delete($id){
        $db = conecta();

        //excluir um usuario da tabela de acordo com o idusuario 
        $sql = "delete from usuario where idusuario = ?";
        $stmt = $db ->prepare($sql);
        //associe o valor do id com um parametro no banco
        $stmt->bindValue(1,$id);
        $stmt->execute();
    }

    function getUsuarios(){
        $db =conecta();
        $sql = "select * from usuario";
        $stmt = $db->prepare($sql);
        $stmt->execute();

        //recupera os resultados das pequisas com um ARRAY
        $resultado = $stmt->fetchALL(PDO::FETCH_ASSOC);
        return $resultado;
    }

    //recebe um nome e retorna um usuario com esse nome
    function getUsuario($nome){
        $db =conecta();
        $sql = "select * from usuario where nome like '$nome%' ";
        $stmt = $db->prepare($sql);
        
        $stmt->execute();
        $resultado = $stmt->fetchALL(PDO::FETCH_ASSOC);
        return $resultado;
    }

    //recebe um id e retorna o usuario desse id 
    function getUsuariobyid($id){
        $db =conecta();
        $sql = "select * from usuario where idusuario = ?";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(1,$id);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario;
    }
?>