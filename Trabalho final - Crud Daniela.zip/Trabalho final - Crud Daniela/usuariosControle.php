<?php
//importa o arquivo
    include_once("usuarioDAO.php");
   //para modificacoes ou informacoes
    session_start();
   //analise se o usuario esta logado
    if($_SESSION['logado'] == false){
        header("location:login.php");
    }
    //analise se a id foi enviada para requisicao HTTP
    if(isset($_REQUEST['id'])){
        $id = $_REQUEST['id']; // ATRIBUI O VALOR 
        delete($id); 
        
        //APOS SER EXCLUIDO É REDIRECIONADO
        header("location:usuarios.php");
    }
?>