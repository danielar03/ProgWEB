<?php
//função que conecta com o banco de dados e retorna a conexão com o banco ou false

function connecta_db(){
    $user="root";
    $pass= "aluno";
    $database= "crud";
    $host= "localhost";

    $db= new PDO("mysql:host=$host;dbname=$database", username: $user, password: $pass);
    
    //definindo o modo de erro para a execução
    $db->setAttribute( PDO::ATTR_ERRMODE,  PDO::ERRMODE_EXCEPTION);

    //veriicando se a conexão foi estabelecida com sucesso
    try{$db-> exec(statement: 'SHOW TABLES'); } catch(PDOExeption $e) {
        echo "". $e->getMessage() ."";
    }

    //checando se a conecxão foi bem sucessida e retorna a conecxão
    if ($db) {  
        return $db;
    } else {
        return false;
    }
}

function check_conn($conn_id): void {
    if ($conn_id) {
        echo "Conexão estabelecida com sucesso!";
    }else {
        echo "Erro ao conectar o banco de dados!";
    }
}

var_dump(value: connecta_db());
check_conn(connecta_db())

?>