<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    O php é uma linguegem de programção interpretada executada no 
    seervidor, diferente do javascript que é executado do 
    lado cliente. O codigo php é executado apartir de uma requisição HTTP
    que chega o servidor HTTP.

</body>
</html>