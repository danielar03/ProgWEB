<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function randomize() {
            var randomValue = Math.floor(Math.random() * 30) + 1;
        
            document.getElementById("result").innerText =
             "Valor aleatório: " + randomValue; }
    </script>
</head>
<body>
    <h1>Gerador de valor aleatório</h1>
    <p>Clique no botão para gerar um número:</p>
    <button onclick="randomize()">Gerar Número</button>
    <p id="result"></p>
</body>
</html>