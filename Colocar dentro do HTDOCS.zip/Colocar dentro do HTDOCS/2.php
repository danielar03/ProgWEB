<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    Somar dois números e imprimir o resultado em um pragrafo;
    <form action =""method="get">
        <label for="inputa">A:</label>
        <input id="inputa"name ="a" type="number">

        <label for ="inputa">B:</label>
        <input id ="inputa"name ="b" type="number">

        <input type ="submit" value ="SOMA">
</from>

    <?php
    //var_dump($_REQUEST);
    if(isset($_REQUEST["a"])&& !isset($_REQUEST["b"])){
        echo "<script>
             alert('informe a e b');
             </script> ";
             die();
    }
    $a=$_REQUEST["a"];
    $b=$_REQUEST["b"];
    echo "<p> SOMA".$a+$b."</p>";

    ?>
    <p> SOMA: <?php echo$a+$b ?> </P>
</body>
</html>