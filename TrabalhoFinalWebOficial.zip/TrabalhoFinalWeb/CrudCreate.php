<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h1>CRIAR REGISTRO</h1>
<form action="create.php" method="post">
    <label for="name">Nome:</label>
    
</body>
</html>