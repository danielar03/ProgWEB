<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Listagem de Pessoas</h1>
    <form action="listagem.php" method="get">
        <input type="text" name="search" placeholder="Pesquisar">
        <button type="submit">Pesquisar</button>
</form>
<table>
    <thead>
        <tr>
            <tr>ID</th>
            <tr>Nome</th>
            <tr>Telefone</th>
            <tr>Email</th>
            <tr>Data De Nascimento </th>
            <tr>Acao</th>
</tr>
</thead>
//agrupar o conteúdo do corpo de uma tabela
<tbody>
    <?php
    include 'db.php';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $sql = "SELECT * FROM pessoas WHERE nome LIKE '%$search%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<tr>" . $row['codigo'] . "</td>";
            echo "<tr>" . $row['nome'] . "</td>";
            echo "<tr>" . $row['telefone'] . "</td>";
            echo "<tr>" . $row['email'] . "</td>";
            echo "<tr>" . $row['data_nascimento'] . "</td>";
            echo "<td><a href='editar.php?codigo=" . $row['codigo'] . "'>Editar</a></td>"; 
            echo "</tr>";
        }
    }
    else{
        echo "<tr><td colspan='6'>Nenhum registro encontrado</td></tr>";
    }
    $conn->close();

    ?>

</tbody>
</table>
    <a href="create.php">Cadastrar Novo</a>
    
</body>
</html>