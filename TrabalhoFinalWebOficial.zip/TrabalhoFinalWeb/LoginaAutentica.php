<?php
session_start();
$username =$_POST['username'];  
$password = $_POST['password'];
if ($username == 'adm' && $password == 'senha123'){
    $_SESSION['loggedin'] = true;
    header('location: dashboard.php'); //login correto
}
else{
    echo 'login ou senha incorretos';
}


?>