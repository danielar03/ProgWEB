<?php
//autenticação de um usuário

    session_start(); //armazene e recupere dados 
    if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){ 
        if($_REQUEST['usuario'] == "admin" && $_REQUEST['senha'] == "1234"){
            $_SESSION['logado'] = true;
            header("location:usuarios.php");
        }else{
            header("location:login.php?login=0");
        }
    }else{
        header("location:login.php?");
    }
?>