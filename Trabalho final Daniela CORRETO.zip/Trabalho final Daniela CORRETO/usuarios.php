<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <style>
        
        *{margin: 0px; border-collapse:collapse;}
        body{}
        #cima{min-height:20vh; display:flex; justify-content: center; align-items:center;}
        #baixo{min-height:80vh; display:flex; justify-content: center; align-items:center;}
        fieldset{display:flex; background-color:white; border: 2px solid black;}
        
        th{border: 1px solid blue; font: 20pt normal black; font-family: georgia; padding:1px;}
        .borda{border: 1px solid blue; font: 20pt normal black; font-family: georgia; padding:1px;}
        input{font: 20pt normal blue; font-family: georgia;}
        button{font: 20pt normal blue; font-family: georgia;}
        #btExcluir{color:pink;}
    </style>
</head>
<body>
    <div id="cima">
        <fieldset> 
       
            <a href="sair.php" id="deslogar"><button id="deslogar">Deslogar</button></a>
            
            <form action="usuarios.php" method="get">
                <input type="text" name="pesquisa" id="pesquisa">
                <input type="submit" value="Pesquisar">
            </form>
        </fieldset>
    </div>
    
    <div id="baixo">
        <fieldset>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Data de Nascimento</th>
                    <th>Email</th>
                    <th>Telefone</th>
                </tr>
                
                <?php 
                //loop para todos os usuarios 
                    for($i=0;$i<count($usuarios);$i++){
                ?>
                        <tr>
                            <td class="borda"><?php echo $usuarios[$i]['idusuario'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['nome'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['dataNasc'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['email'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['telefone'];?></td>

                            //Falta a opcao de editar
                           
                            <td><form action="usuariosControle.php" method="post">
                                <input type="number" name="id" value="<?php echo $usuarios[$i]['idusuario'];?>" hidden>
                                <input type="submit" value="Excluir" id="btExcluir">
                            </form></td>
                        </tr>
                <?php
                    }
                ?>
            </table>
        </fieldset>
    </div>
</body>
</html>